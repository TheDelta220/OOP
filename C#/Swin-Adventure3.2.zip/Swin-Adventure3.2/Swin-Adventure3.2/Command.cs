﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_Adventure3._2
{
    public abstract class Command : IdentifiableObject
    {
        public Command(string[] ids) : base(ids) 
        { 
            
        }
        public abstract string Execute(Player p, string[] text);
        
    }
}
