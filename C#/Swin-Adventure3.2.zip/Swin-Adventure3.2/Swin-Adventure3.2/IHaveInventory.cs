﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Swin_Adventure3._2
{
    public interface IHaveInventory
    {
        GameObject Locate(string id);
        
        string Name 
        {
            get;
        }
    }
}
